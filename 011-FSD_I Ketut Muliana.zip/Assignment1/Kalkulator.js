var a = 10;
let b = 2;

console.log("Sum: ", a + b);
console.log("Difference: ", a - b);
console.log("Product: ", a * b);
console.log("Quotient: ", a / b);
console.log("Remainder: ", a % b);
console.log("Value of", a, "after increament: ", (a += 1));
console.log("Value of", b, "after decreament: ", (b -= 1));
